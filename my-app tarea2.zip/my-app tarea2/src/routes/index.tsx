import { createFileRoute } from '@tanstack/react-router'
import '../App.css'
import Candidate from '@/components/candidate'
import type { CandidateType } from '@/types/candidates'

export const Route = createFileRoute('/')({
  component: App,
})


/* Lista */
function App() {
  return (
    <div className="flex flex-row flex-wrao gap-4 p-4 justify-around items-center">
      <Candidate 
      name= "Liliana" 
      age={36} 
      experience={5} 
      skills={['JavaScript', 'React', 'Node.js']} 
      status={'Hired'} 
      working={true}
      
      />
    </div>
  )
}
/*
const  App = () => {
    const candidates: Array<CandidateType> = [
  {
    name: 'Richard Salavarria',
    age: 35,
    experience: 12,
    skills: ['AWS', 'Ubikiti', 'Cisco'],
    status: 'Pending',
    working: true,
  },
  {
    name: 'Kerly Flor',
    age: 40,
    experience: 15,
    skills: ['HTML', 'React'],
    status: 'Interviewing',
    working: false,
  },
  {
    name: 'Marcos Llerena',
    age: 34,
    experience: 9,
    skills: ['CSS'],
    status: 'Interviewing',
    working: true,
  },
  
]
 return (
<ul >
      {candidates.map((candidate) => (
        <li key={candidate.name}> { 
        <Candidate 
      name= {candidate.name}
      age={candidate.age} 
      experience={candidate.experience} 
      skills={candidate.skills} 
      status={candidate.status} 
      working={candidate.working}
      />
        }</li>
            
          ))}
    </ul>
  );
};
*/

/*
export const getCandidates = () => {
    return data;
}*/