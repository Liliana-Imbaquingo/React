import type { CandidateType } from "@/types/candidates";
import { cn } from "@/utils/styles";

/* type CandidateProps = Partial< {
    name: string;
    age: number;
    city: string;
    country: string;
}>;*/

type CandidateProps = CandidateType & {
    className?: string;
    //: (name:string)=> void;
};

const Candidate = (props: CandidateProps) => {
const { name, age, experience, skills, status, working } = props;

    return (
    <div
     className={cn(props.className,
     'border border-gray-300 shadow-md flex-col rounded-lg p-4 ',
     ' min-w-[250px]')}>
        <div
        className="flex items-start justify-between mb-2">
        <h2 className="text-xl font-bold"> {name?.toUpperCase()}</h2>
        <span className={
            cn(getStatusColor(status), 'text-sm font-medium px-2 py-1 rounded-full')
        }
        >{status.toUpperCase()}
        </span>
        </div>
        
        <p className="text-gray-500">Age: {age}</p>
        <p className="text-gray-500">Experience: {experience} years</p>
        
        <p
        className={cn(
                'text-gray-500',
                working? 'text-green-600' : 'text-red600'
            )}
        >Working: {working ? 'Yes' : 'No'}{isWorkingCheck()}</p>
        <h3 className="text-lg font-semibold mt-2">Skills:</h3>
        <ol className="list-decimal list-inside text-gray-700">
        {skills.join(', ')}
        </ol>
        <button className="rounded bg-purple-400 hover:bg-purple-200" onClick={() =>updateClipboard() }>Copiar datos</button>
    </div>
    );

function updateClipboard() {
  navigator.clipboard.writeText("Name:"+name+" Age: "+age+" Experience: "+experience+"years Status: "+status+" Working: "+working+" Skills: "+skills).then(
    () => {
      /* clipboard successfully set */
      alert('Datos Copiados');
      
    },
    () => {
      /* clipboard write failed */
      alert('Error al copiar al portapapeles');
    },
  );
}

function isWorkingCheck(){
    if(working){
        return <span>✅</span>
    }
        return
}

function getStatusColor(status: CandidateType['status']) {
    if(status === 'Hired') {
        return 'bg-green-600';
    }

    if(status === 'Interviewing') {
        return 'bg-yellow-600';
    }
    if(status === 'Pending') {
        return 'bg-blue-600';
    }
    if(status === 'Refused') {
        return 'bg-red-600';
    }
     return 'bg-blue-600';
}
};
/*
function randomNumber() {
    return Math.floor(Math.random()*100);

}*/
    
/*function Candidate() {
    return <p>candidate</p>;
}*/



export default Candidate;